# Android QRCode Example
Generate and read QRCode in Android app with the custom object. In this example, we’ve used Zxing library for reading and generating QRCode. 

Find Step by Step Tutorial here => http://codinginfinite.com/qrcode-generator-and-reader-android-example/
