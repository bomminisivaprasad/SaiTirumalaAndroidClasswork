package com.spartons.qrcodegeneratorreader.helper;

public class Constants {

    public static final String QR_CODE_STRING = "encrypted_string";
}
