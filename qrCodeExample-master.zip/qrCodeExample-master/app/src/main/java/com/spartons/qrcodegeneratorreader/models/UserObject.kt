package com.spartons.qrcodegeneratorreader.models

class UserObject(var fullName: String, var age: Int)