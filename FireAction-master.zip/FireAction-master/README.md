# FireAction
Final Year Project

# Instruction

The application is done in the Android Environment and it does not any other tools to compile. Therefore, it only needs Android Studio to run the application. 
Step to run the application

1.	Open the application in Android Studio.
2.	You can only use a real phone to test the application as it used many features that do not support the visual device.
3.	Run the application on your device.
4.	Accept all the required permission as it affected the core functions of the application.
5.	The application is ready to use.


# The application

The application contains 4 triggers and 6 actions which can produce a 24 combination of functions to help people sort out their daily life. The application is extremely useful when the user does not have their mobile device around. It can execute a subsequently automated process that is predefined by the user.  The function (automated process) is combined with the trigger and action where the trigger tells the system when the process is going to be executed and the action tells the system how the process is going to be executed.

# How to use

The function (automated process) is created by the user, the user can decide the feature of the function depends on his/her demand. For example, if the user is a forgetful person who is always missing his/her mobile phone that is in silence mode, he/she wishes to use the application to find the mobile phone easily. The user can use the SMS trigger along with volume action to perform this function. 

The SMS trigger requires the user to predefined a specific text to activate the function, the text can be any characters or number but it will be better to add the special symbol like %, $ or @ before and right after the specific text such as %Turn back volume% or #Volume up#. The special symbols help to avoid the collision of the SMS text message happens in the daily life. Then, the user can set up the volume action to turn back the mobile phone. The volume action allows the user to choose to turn back any type of the volume in any number. 

For example, the user can choose to turn the Ring volume to 100% but the Music volume to 0%.  The combination of the SMS trigger and volume action enable the user to find the location of the mobile phone by turning the volume back. 

The **imagination** of the user is playing a key role in the application. The different combinations could perform different tasks or services. For now, there are only 24 combinations available in the application. The interesting combination that you might want to try is shown as below.


# Example

| No | Trigger           | Action		|Description                                                                                  |
|----|-------------------|--------------|---------------------------------------------------------------------------------------------|
| 1  | SMS/Text Message  | Volume		|Turn back volume by SMS/Text Message                                                         |
| 2  | Timer/Alarm	     | Volume		|Turn back volume after you finish the classes                                                |
| 3  | Accelerator	     | Torchlight	|Move left to turn on the torchlight and move right to turn off the torch light               | 
| 4  | Accelerator	     | HTTP		    |Shake the phone to send a HTTP request to your home automation server to turn on/off a light | 

